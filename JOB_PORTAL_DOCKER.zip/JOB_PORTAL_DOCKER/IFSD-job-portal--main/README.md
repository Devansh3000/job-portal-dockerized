# Job Portal – Full Stack (Dockerized)

A full-stack Job Portal application built with **React (Vite)** for the frontend and **Node.js + Express** for the backend.  
The entire project is **Dockerized** using Docker Compose for easy setup and deployment.

---

## 🚀 Tech Stack

### Frontend
- React (Vite)
- HTML, CSS, JavaScript
- Axios

### Backend
- Node.js
- Express.js
- MongoDB (can be local or cloud)
- JWT Authentication

### DevOps
- Docker
- Docker Compose
- Nginx (for frontend production build)

---

## 📁 Project Structure

